-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2021 at 04:53 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prosmart`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `photo`, `banner`, `status`, `created_at`, `updated_at`) VALUES
(2, '1621638441.jpg', '1621638341.jpg', 1, '2021-05-18 12:44:57', '2021-05-21 21:07:21');

-- --------------------------------------------------------

--
-- Table structure for table `about_translations`
--

CREATE TABLE `about_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `about_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaData` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `about_translations`
--

INSERT INTO `about_translations` (`id`, `locale`, `about_id`, `title`, `slug`, `description`, `metaData`, `metaDescription`, `keywords`) VALUES
(2, 'en', 2, 'prosmart', 'prosmart', '<p><strong>ProSmart co&nbsp;</strong>is one of the leading companies in the field of information technology which has professional technical staff who have a high level of expertise, bearing in front of several of the goals sought to be achieved for all our customers.<br />\r\n&ndash; The continued support and guidance to all of its customers in the domestic market and in the global market.<br />\r\n&ndash; Increase sales volume of customers through the use of information technology in various forms to display and market customer&rsquo;s products and services in a professional style.<br />\r\n&ndash; The rapid spread of customers through various methods of electronic advertising.<br />\r\n&ndash; To increase profits for customers through the application of many information system applications and integrated solutions for the various follow-up of the company&rsquo;s profit margin.<br />\r\n&ndash; Permanent and continuous communication between companies and their customers through the provision of different application systems. The company is striving to achieve these goals using a variety of highly professional staff, consultants and specialists in the field of marketing to meet customers&rsquo; needs</p>', 'prosmart', 'prosmart', 'prosmart');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `film` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaData` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `title`, `photo`, `banner`, `status`, `slug`, `description`, `film`, `metaData`, `metaDescription`, `keywords`, `created_at`, `updated_at`) VALUES
(1, 'EIC Engineer', '1621524700.png', NULL, 1, NULL, NULL, 'https://www.youtube.com/watch?v=k_RtS3sag1Y', 'EIC Engineering', 'EIC Engineering', 'EIC Engineering', '2021-05-18 13:33:10', '2021-05-22 19:55:44'),
(2, 'Diet Delight', '1621628550.png', NULL, 1, NULL, NULL, 'https://www.youtube.com/watch?v=k_RtS3sag1Y', 'Diet Delight', 'Diet Delight', 'Diet Delight', '2021-05-21 18:22:30', '2021-05-24 06:46:50'),
(3, 'Style Team', '1621628577.jpg', NULL, 1, NULL, NULL, 'https://www.youtube.com/watch?v=k_RtS3sag1Y', 'Style Team', 'Style Team', 'Style Team', '2021-05-21 18:22:57', '2021-05-24 06:47:06'),
(4, 'Egytal Group', '1621628601.jpg', NULL, 1, NULL, NULL, NULL, 'Egytal Group', 'Egytal Group', 'Egytal Group', '2021-05-21 18:23:21', '2021-05-21 18:23:23'),
(6, 'Care Smile', '1621771035.jpg', NULL, 1, NULL, NULL, NULL, 'Care Smile', 'Care Smile', 'Care Smile', '2021-05-23 09:57:15', '2021-05-23 09:57:17'),
(7, 'Shabana Group', '1621771119.png', NULL, 1, NULL, NULL, NULL, 'Shabana Group', 'Shabana Group', 'Shabana Group', '2021-05-23 09:58:39', '2021-05-23 09:58:42'),
(8, 'Queen', '1621771227.png', NULL, 1, NULL, NULL, NULL, 'Queen', 'Queen', 'Queen', '2021-05-23 10:00:27', '2021-05-23 10:00:29');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `home_banners`
--

CREATE TABLE `home_banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `home_banners`
--

INSERT INTO `home_banners` (`id`, `title`, `banner`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Home1', '1621770085.jpg', 1, '2021-05-19 10:57:37', '2021-05-23 09:41:26'),
(2, 'Home2', '1621432090.png', 1, '2021-05-19 11:00:20', '2021-05-19 11:48:12'),
(4, 'Home3', '1621432843.jpeg', 1, '2021-05-19 11:00:45', '2021-05-19 12:00:44');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(10) UNSIGNED NOT NULL,
  `disk` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `directory` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aggregate_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mediables`
--

CREATE TABLE `mediables` (
  `media_id` int(10) UNSIGNED NOT NULL,
  `mediable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mediable_id` int(10) UNSIGNED NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_05_17_204843_create_mediable_tables', 1),
(5, '2021_05_18_102914_create_abouts_table', 1),
(6, '2021_05_18_102920_create_about_translations_table', 1),
(7, '2021_05_18_103019_create_services_table', 1),
(8, '2021_05_18_103046_create_service_translations_table', 1),
(12, '2021_05_18_103103_create_clients_table', 2),
(15, '2021_05_19_080850_create_projects_table', 3),
(16, '2021_05_19_081247_create_project_translations_table', 3),
(17, '2021_05_18_103444_create_settings_table', 4),
(18, '2021_05_19_121423_create_home_banners_table', 5),
(19, '2021_05_19_135346_create_work_dones_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `photo`, `banner`, `status`, `created_at`, `updated_at`) VALUES
(2, '1621413579.jpg', NULL, NULL, '2021-05-19 06:39:39', '2021-05-19 06:39:39');

-- --------------------------------------------------------

--
-- Table structure for table `project_translations`
--

CREATE TABLE `project_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaData` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_translations`
--

INSERT INTO `project_translations` (`id`, `locale`, `project_id`, `title`, `slug`, `description`, `metaData`, `metaDescription`, `keywords`) VALUES
(2, 'en', 2, 'Buckingham Africa', 'buckingham-africa', '<p><strong>ProSmart co&nbsp;</strong>is one of the leading companies in the field of information technology which has professional technical staff who have a high level of expertise, bearing in front of several of the goals sought to be achieved for all our customers.</p>', 'Buckingham Africa', 'Buckingham Africa', 'Buckingham Africa');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `video` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `photo`, `banner`, `status`, `video`, `created_at`, `updated_at`) VALUES
(1, '1621352775.jpg', '1621758693.png', 1, NULL, '2021-05-18 13:46:15', '2021-05-23 06:31:34'),
(2, '1621757300.png', '1621758705.jpg', 1, NULL, '2021-05-23 06:08:22', '2021-05-23 06:31:46'),
(3, '1621757406.png', '1621758718.jpg', 1, NULL, '2021-05-23 06:10:06', '2021-05-23 06:31:59'),
(4, '1621757484.jpg', '1621758735.jpg', 1, NULL, '2021-05-23 06:11:25', '2021-05-23 06:32:16'),
(5, '1621757554.jpg', '1621758747.jpg', 1, NULL, '2021-05-23 06:12:34', '2021-05-23 06:32:28'),
(6, '1621932094.jpg', '1621932095.jpg', 1, 'https://www.youtube.com/watch?v=oQQbPhfsASI', '2021-05-25 06:41:36', '2021-05-25 06:46:14');

-- --------------------------------------------------------

--
-- Table structure for table `service_translations`
--

CREATE TABLE `service_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `importance` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaData` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_translations`
--

INSERT INTO `service_translations` (`id`, `locale`, `service_id`, `title`, `slug`, `description`, `importance`, `metaData`, `metaDescription`, `keywords`) VALUES
(1, 'en', 1, 'Web Design & Development', 'web-design-development', '<p>We are introducing the best website design and development for your company. With a large number of successfully completed projects and happy clients, we guarantee best designing of your website that will help you to maximize your ROI.</p>\r\n\r\n<p>The website is the most important platform for representing your company electronically. Just as you care about the appearance of your company on the ground, your website is no less important, but more important.<br />\r\nWe support you in the new world of web design and development.</p>\r\n\r\n<p><strong>Website Redesign</strong><br />\r\nMost sites should be redesigned, upgraded or even enhanced for web search tools as new algorithms impact how your website is found according to the searchers on the internet.<br />\r\nProsmart for information technology has an in-house team of software engineers that can enhance any website whether stylishly or from a functional point of view.<br />\r\nOnce you&rsquo;ve chosen to give your website, which means your online business, a radical new look by updating and upgrading it, there are a couple of essential standards are you must consider when trying to accomplish your business goals.<br />\r\nThe one thing you should not do is responding to your competitors on the off chance that you feel they have a better website with more beautiful design or better functionality. Despite the fact that being competitive is fundamental for the survival of any business, acting deliberately and setting yourself up to beat the rest is similarly critical, particularly when it includes the redesigning of key features of your business.<br />\r\nToday online businesses realize that each new website has a momentous capability of bringing them exceptional ROI. This potential is directed by various elements including your Services, kind of products and your industry and so on.</p>', NULL, 'Web Design & Development', 'Web Design & Development', 'Web Design & Development'),
(2, 'en', 2, 'E-Commerce Website', 'e-commerce-website', '<p><strong>Prosmart for information technology&nbsp;</strong>designs and develops E-commerce websites as per the latest technologies to meet your business needs, surpass your expectations to help you to get the ROI you&rsquo;ve been looking for.<br />\r\nE-Commerce website gives you advantages to a business by allowing users to buy their choicest items online as opposed to going to shops and mortar stores.</p>\r\n\r\n<p><br />\r\n<strong>Prosmart for information technology</strong>&nbsp;has the capability to created turn-key e-Commerce solutions alongside e-Commerce in your current website<br />\r\nThe variety of custom E-commerce Solutions including (B2C &ndash; B2B) e-Commerce website development to meet the business needs.<br />\r\nOur services (including E-commerce website design, development, B2B/B2C, business e-Commerce, store retail storefront, and shopping basket, Payment gateway portals and some other Custom electronic e-Commerce solutions.</p>', NULL, 'E-Commerce Website', 'E-Commerce Website', 'E-Commerce Website'),
(3, 'en', 3, 'Mobile Website Development', 'mobile-website-development', '<p>To have a special application for your business or project; is one of the best technical solutions that keep you in constant communication with your customers.<br />\r\nprosmart co design and program your application for you, and add to it all the interactive functions that ensure the convenience of customer use and preference for your application, no matter how many competing applications.<br />\r\nThe continuous research and development of the app confirms your competitiveness with an interactive and preferred application by your customers.</p>\r\n\r\n<p><br />\r\n<strong>Prosmart for information technology</strong>&nbsp;as a part of mobile&nbsp;development Companies in Egypt, Spend significant time in responsive websites.<br />\r\nIf your business website isn&rsquo;t responsive and you don&rsquo;t have time or spending plan to redesign your website, however, would like your clients to have a rich Mobile experience, then a mobile website could be a decent alternative for you.<br />\r\nMobile interchanges have grown quickly with the development of the cell phone processor, and moveable specialized gadgets are presently a &ldquo;front of psyche and palm of hand&rdquo; sympathy toward a great many people. The force of useable data and significant procedure is currently a created reality which has a verifiable intrinsic advantage for businesses that are searching for more approaches to connect with a chosen market in a financially savvy and gainful way.</p>', NULL, 'Mobile Website Development', 'Mobile Website Development', 'Mobile Website Development'),
(4, 'en', 4, 'Configure your website for SEO', 'seo', '<p><strong>It&rsquo;s Time to Dominate Page 1 of Google</strong><br />\r\nGetting to the 1st page (top) of Google is the first task, staying there is far more important.<br />\r\nAt&nbsp;<strong>Prosmart&nbsp;</strong>we solely perform friendly, best practice SEO activities giving your website not only the opportunity to rise in the rankings of Google but keeping you there for good.</p>\r\n\r\n<p><br />\r\nWe do a comprehensive search on the most relevant and top search words on Google<br />\r\nWe study the audience of targeted words in terms of their behavior and interest<br />\r\nWe analyze competitors and identify their strengths and weaknesses<br />\r\nWe modify the programming and design of the site completely so as to conform to the best programmatic and cognitive format to capture the priority of appearing in the search results<br />\r\nFull site configuration and configuration for SEO Friendly<br />\r\nWrite exclusive content tailored to the customer&#39;s domain and the interests of the target audience, and develop a stronger strategy after taking advantage of their competitors&#39; mistakes and weaknesses<br />\r\nBacklink (Back-Links) legitimacy is compatible with the laws of Google professionally and in more than one style and method<br />\r\nPublish your site on social media sites such as Facebook, Twitter, Instagram, Google Plus, Pinterest and others to gain strong signals Social Signal to accelerate your ranking in the search engine and pass more traffic on your website More Traffic<br />\r\nWe determine when to appear on the first page of search results and when to appear on the first page of the first page in accordance with your target audience and the strategy developed by the SEO Specialist responsible for your website.</p>', NULL, 'SEO', 'SEO', 'SEO'),
(5, 'en', 5, 'Social Media Campaigns', 'social-media-campaigns', '<ul>\r\n	<li>Social Media Marketing is a very effective and centralized online marketing channel. So we manage and follow the pages on Facebook, Twitter, Instagram, YouTube, LinkedIn and other social media. By creating the right content and creating creative designs for the product to reach a look that attracts the attention of the target customers. We also follow up customer inquiries and respond to them as quickly as the best customer service in a language that suits the nature of the customer and give them the best impression of service providers and your brand.</li>\r\n	<li>In addition, the possibility of funded advertising campaigns to reach customers interested in the product.</li>\r\n	<li>We create customer awareness of our customer&#39;s brand and create a product identity through the content provided, your brand graphics and the capacity to spread on all social media.</li>\r\n	<li>The goal is to e-market your product by managing and running all advertising campaigns to maximize profit in the least time and at the lowest cost</li>\r\n</ul>', NULL, 'Social Media Campaigns', 'Social Media Campaigns', 'Social Media Campaigns'),
(7, 'en', 6, 'Documentary Films', 'documentary-films', '<h1>A&nbsp;documentary film&nbsp;or&nbsp;documentary&nbsp;is a non-fictional motion-picture&nbsp;intended to &quot;document reality, primarily for the purposes of instruction, education, or maintaining a historical-record&quot;.&nbsp;Bill Nicholas has characterised the documentary in terms of &quot;a filmmaking practice, a cinematic tradition, and mode of audience reception [that remains] a practice without clear boundaries&quot;.<br />\r\n&nbsp;</h1>', '<ul>\r\n	<li>Eliminate Repeat Entry</li>\r\n	<li>Simpliy Communication</li>\r\n</ul>', 'Documentary Films', 'Documentary Films', 'Documentary Films');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `data`, `photo`, `created_at`, `updated_at`) VALUES
(2, 'SocialMedia', 'a:1:{s:4:\"data\";a:4:{s:8:\"facebook\";s:1:\"#\";s:7:\"twitter\";s:1:\"#\";s:7:\"youtube\";s:1:\"#\";s:8:\"linkedin\";s:1:\"#\";}}', NULL, NULL, '2021-05-23 10:54:45'),
(3, 'SiteSetting', 'a:1:{s:4:\"data\";a:2:{s:7:\"address\";a:1:{s:2:\"en\";s:8:\"Prosmart\";}s:11:\"description\";a:1:{s:2:\"en\";s:190:\"<p>information technology which has professional technical staff who have a high level of expertise, bearing in front of several of the goals sought to be achieved for all our customers.</p>\";}}}', NULL, NULL, '2021-05-23 11:05:23'),
(6, 'Recent', 'a:1:{s:4:\"data\";a:2:{s:7:\"address\";a:1:{s:2:\"en\";s:63:\"MarketU “The best marketing doesn’t feel like marketing.”\";}s:11:\"description\";a:1:{s:2:\"en\";s:763:\"<p>E-commerce (electronic commerce) is the buying and selling of goods and services, or the transmitting of funds or data, over an electronic network, primarily the internet. These business transactions occur either as business-to-business (B2B), business-to-consumer (B2C), consumer-to-consumer or consumer-to-business. The terms e-commerce and e-business are often used interchangeably. The term e-tail is also sometimes used in reference to the transactional processes&nbsp;that make up online retail shopping.</p>\r\n\r\n<p>In the last decade, widespread use of e-commerce platforms such as Amazon and eBay has contributed to substantial growth in online retail. In 2007, e-commerce accounted for 5.1% of total retail sales; in 2019, e-commerce made up 16.0%.</p>\";}}}', '1621549271.png', NULL, '2021-05-23 11:43:57'),
(8, 'ContactUs', 'a:1:{s:4:\"data\";a:3:{s:6:\"mobile\";s:10:\"0111111111\";s:5:\"email\";s:15:\"admin@admin.com\";s:7:\"address\";s:10:\"124 street\";}}', NULL, NULL, '2021-05-23 10:44:16'),
(9, 'ClientsBanner', 'a:1:{s:4:\"data\";a:1:{s:7:\"address\";s:6:\"Banner\";}}', '1621714581.png', NULL, '2021-05-22 18:16:21');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Agnes Cremin', 'admin@admin.com', NULL, '$2y$10$OWFlNqDpgQbP1ciyLg0Lse4qqHyarHG/iRSCxqRF0mKOBZIlgVQn6', NULL, '2021-05-18 09:42:41', '2021-05-18 09:42:41');

-- --------------------------------------------------------

--
-- Table structure for table `work_dones`
--

CREATE TABLE `work_dones` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `work_dones`
--

INSERT INTO `work_dones` (`id`, `title`, `photo`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Web development', '1621434694.jpg', 1, '2021-05-19 12:31:35', '2021-05-19 12:45:55'),
(2, 'E-commerce', '1621435015.png', 1, '2021-05-19 12:36:56', '2021-05-19 12:45:56'),
(3, 'Mobile app', '1621435061.jpg', 1, '2021-05-19 12:37:41', '2021-05-19 12:45:57'),
(4, 'SEO', '1621435092.jpg', 1, '2021-05-19 12:38:12', '2021-05-19 12:45:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `about_translations`
--
ALTER TABLE `about_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `about_translations_about_id_locale_unique` (`about_id`,`locale`),
  ADD KEY `about_translations_locale_index` (`locale`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_banners`
--
ALTER TABLE `home_banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `media_disk_directory_filename_extension_unique` (`disk`,`directory`,`filename`,`extension`),
  ADD KEY `media_aggregate_type_index` (`aggregate_type`);

--
-- Indexes for table `mediables`
--
ALTER TABLE `mediables`
  ADD PRIMARY KEY (`media_id`,`mediable_type`,`mediable_id`,`tag`),
  ADD KEY `mediables_mediable_id_mediable_type_index` (`mediable_id`,`mediable_type`),
  ADD KEY `mediables_tag_index` (`tag`),
  ADD KEY `mediables_order_index` (`order`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_translations`
--
ALTER TABLE `project_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_translations_project_id_locale_unique` (`project_id`,`locale`),
  ADD KEY `project_translations_locale_index` (`locale`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_translations`
--
ALTER TABLE `service_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `service_translations_service_id_locale_unique` (`service_id`,`locale`),
  ADD KEY `service_translations_locale_index` (`locale`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `work_dones`
--
ALTER TABLE `work_dones`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `about_translations`
--
ALTER TABLE `about_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `home_banners`
--
ALTER TABLE `home_banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `project_translations`
--
ALTER TABLE `project_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `service_translations`
--
ALTER TABLE `service_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `work_dones`
--
ALTER TABLE `work_dones`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `about_translations`
--
ALTER TABLE `about_translations`
  ADD CONSTRAINT `about_translations_about_id_foreign` FOREIGN KEY (`about_id`) REFERENCES `abouts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `mediables`
--
ALTER TABLE `mediables`
  ADD CONSTRAINT `mediables_media_id_foreign` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `project_translations`
--
ALTER TABLE `project_translations`
  ADD CONSTRAINT `project_translations_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `service_translations`
--
ALTER TABLE `service_translations`
  ADD CONSTRAINT `service_translations_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
